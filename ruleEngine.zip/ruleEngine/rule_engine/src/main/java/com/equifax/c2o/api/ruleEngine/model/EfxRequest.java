
package com.equifax.c2o.api.ruleEngine.model;

import lombok.Data;

@Data
public class EfxRequest {
    private String exampleField;
}
